/**
 * $Id: SystemPropertiesTable.java,v 1.1.1.1.2.1 2000/10/25 07:58:17 dgilbert Exp $
 */

package com.jrefinery.util.ui;

public class SystemPropertiesTable {

  public SystemPropertiesTable() {
  }
}